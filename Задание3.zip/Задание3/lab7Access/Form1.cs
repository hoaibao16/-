﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
namespace lab7Access
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=H:\Mydoc\data base\Lab6.accdb");
        OleDbCommand cmd = new OleDbCommand();
        string query1="",query2="";

        private void Form1_Load(object sender, EventArgs e)
        {
            cmd.Connection = con;
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            string query = "Select Фамилия, Имя, Отчество, Адрес from Пациент1";
            Show(query);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            con.Close();
        }

        public void Show(string query)
        {
            try
            {
                cmd.CommandText = query;
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(cmd);
                DataSet ds = new DataSet();
                dataAdapter.Fill(ds);
                datagv.DataSource = ds.Tables[0];
                txt_mdname.Text = "";
                txt_surname.Text = "";
                txt_adress.Text = "";
                txt_name.Text = "";
            }
            catch (Exception fault)
            {
                MessageBox.Show(fault.Message);
            }
        }


        private void btn_Run_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            string query_condition = cb_Access.SelectedItem.ToString();
            string method_conditon = cb_method.SelectedItem.ToString();
            switch(query_condition)
            {
                case "ADD":
                    switch (method_conditon)
                    {
                        case "NON_PARAMETER":
                            query1 = "EXEC labtam '" + txt_surname.Text + "','" + txt_name.Text + "','" + txt_mdname.Text + "','" + txt_adress.Text + "'";
                            break;
                        case "PARAMETER":
                            query1 = "EXEC labtam '@Surname','@name','@mdname','@adress'";
                            //define
                            cmd.Parameters.AddWithValue("@Surname", txt_surname.Text);
                            cmd.Parameters.AddWithValue("@name", txt_name.Text);
                            cmd.Parameters.AddWithValue("@mdname", txt_mdname.Text);
                            cmd.Parameters.AddWithValue("@adress", txt_adress.Text);
                            break;
                    }
                    query2 = "Select Фамилия, Имя, Отчество, Адрес from Пациент1";
                    break;
                case "DELETE":
                    switch (method_conditon)
                    {
                        case "NON_PARAMETER":
                            query1 = "DELETE FROM Пациент1 where Отчество='" + txt_mdname.Text + "' OR Фамилия ='" + txt_surname.Text + "' OR Адрес='" + txt_adress.Text + "' OR Имя ='" + txt_name.Text + "'";
                            break;
                        case "PARAMETER":
                            query1 = "DELETE FROM Пациент1 where Фамилия=@surname OR Имя=@name";
                            cmd.Parameters.AddWithValue("@surname", txt_surname.Text);
                            cmd.Parameters.AddWithValue("@name", txt_name.Text);
                            break;
                    }
                    query2 = "Select Фамилия, Имя, Отчество, Адрес from Пациент1";
                    break;
                case "QUERY WITH CONDITION":
                    switch (method_conditon)
                    {
                        case "NON_PARAMETER":
                            query2 = "Select Фамилия, Имя, Отчество, Адрес from Пациент1 Where Фамилия= '" + txt_surname.Text + "' OR Имя='" + txt_name.Text + "' Or Отчество='" + txt_mdname.Text + "' Or Адрес='" + txt_adress.Text + "'";
                            break;
                        case "PARAMETER":
                            query2 = "Select Фамилия, Имя, Отчество, Адрес from Пациент1 Where Фамилия=@Surname OR Имя=@name Or Отчество=@mdname Or Адрес=@adress";
                            //define
                            cmd.Parameters.AddWithValue("@Surname", txt_surname.Text);
                            cmd.Parameters.AddWithValue("@name", txt_name.Text);
                            cmd.Parameters.AddWithValue("@mdname", txt_mdname.Text);
                            cmd.Parameters.AddWithValue("@adress", txt_adress.Text);
                            break;
                    }
                    query1 = query2;
                    break;
             }

            try
            {
                cmd.CommandText = query1;
                cmd.ExecuteNonQuery();
                MessageBox.Show("successfully");
                Show(query2);
            }
            catch (Exception fault)
            {
                MessageBox.Show(fault.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void cb_Access_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cb_Access.SelectedIndex)
            {
                case 1:
                    lb_mdname.Visible = false;
                    lb_adress.Visible = false;
                    txt_mdname.Visible = false;
                    txt_adress.Visible = false;
                    break;
                case 2:
                    lb_mdname.Visible = false;
                    lb_adress.Visible = false;
                    txt_mdname.Visible = false;
                    txt_adress.Visible = false;
                    break;
                default:
                    lb_mdname.Visible = true;
                    lb_adress.Visible = true;
                    txt_mdname.Visible = true;
                    txt_adress.Visible = true;
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                cmd.CommandText = "EXEC queryinsert '1','2','3','4'";
                cmd.ExecuteNonQuery();
                cmd.Clone();
                string query = "Select Фамилия, Имя, Отчество, Адрес from Пациент1";
                Show(query);
            }
            finally
            {
                con.Close();
            }
        }
    }

}